(function () {
  var JY_USER = null;
  try { JY_USER = JSON.parse(localStorage.getItem('jyn_user') || 'null'); } catch (e) {}
  var JY_GUEST = !!(JY_USER && JY_USER.guest);
  function deny() { return Promise.resolve({ ok: false, error: '游客模式只读，请先登录' }); }
  // 退出按钮
  function addExit() {
    if (document.getElementById('jynExit')) return;
    var b = document.createElement('button');
    b.id = 'jynExit'; b.textContent = '×'; b.title = '退出鲸屿';
    b.style.cssText = 'position:fixed;right:14px;top:10px;z-index:2147483647;width:30px;height:30px;border-radius:50%;border:1px solid rgba(22,104,227,.35);background:rgba(255,255,255,.85);color:#1668e3;font-size:18px;line-height:1;cursor:pointer;box-shadow:0 2px 10px rgba(22,104,227,.15)';
    b.onclick = function () { try { window.chrome.webview.postMessage('exit'); } catch (e) { window.close(); } };
    document.body.appendChild(b);
    var d = document.getElementById('demoTag'); if (d) d.style.display = 'none';
  }
  // pywebview 兼容层（把控制台真实数据接到本地 API）
  function installShim() {
    if (window.pywebview && window.pywebview.api) return;
    function g(u) { return fetch(u).then(function (r) { return r.json(); }); }
    window.pywebview = { api: {
      get_overview: function () { return g('/api/overview'); },
      get_plugins: function () { return g('/api/plugins'); },
      get_personas: function () { return g('/api/personas'); },
      get_groups: function () { return g('/api/groups'); },
      get_proactive: function () { return Promise.resolve({ ok: true, running: false }); },
      start_proactive: function () { return JY_GUEST ? deny() : Promise.resolve({ ok: false, error: '只读控制台' }); },
      stop_proactive: function () { return JY_GUEST ? deny() : Promise.resolve({ ok: true }); },
      set_plugin_enabled: function () { return JY_GUEST ? deny() : Promise.resolve({ ok: false, error: '只读控制台，请到 AstrBot 后台操作' }); },
      get_voice_status: function () { return Promise.resolve({ ok: true, engine: 'edge-tts', voice: 'zh-CN-XiaoyiNeural' }); },
      get_accounts: function () { return g('/api/accounts'); },
      get_platforms: function () { return g('/api/platforms'); },
      get_logs: function () { return Promise.resolve({ ok: true, logs: [] }); },
      set_main_uin: function () { return Promise.resolve({ ok: false, error: '账号由服务器托管' }); },
      start_services: function () { return Promise.resolve({ ok: false, error: '服务由服务器托管' }); },
      stop_services: function () { return Promise.resolve({ ok: false, error: '服务由服务器托管' }); },
      set_sf_key: function () { return Promise.resolve({ ok: false, error: 'Key 请写入云端配置' }); },
      install_ffmpeg: function () { return Promise.resolve({ ok: false, error: '服务器已内置 ffmpeg' }); },
      add_account: function () {
        return g('/api/add_account').then(function (d) {
          if (d && d.webui) { try { window.chrome.webview.postMessage('open:' + d.webui); } catch (e) {} }
          return d;
        });
      },
      switch_account: function () { return Promise.resolve({ ok: false, error: '单账号模式，请到 NapCat 控制台切换' }); },
      bot_online: function () { return Promise.resolve({ ok: false, error: '机器人由服务器托管' }); },
      bot_offline: function () { return Promise.resolve({ ok: false, error: '鲸屿只读，不会下线机器人' }); },
      get_qrcode: function () { return Promise.resolve({ ok: false, ready: false, error: '扫码请到 NapCat 控制台' }); },
      get_version: function () { return g('/api/version'); },
      get_raw_config: function () { return g('/api/raw_config'); }
    } };
  }

  function addScan() {
    if (JY_GUEST) return;
    if (document.getElementById('jynScan')) return;
    var s = document.createElement('button');
    s.id = 'jynScan'; s.textContent = '扫码登录我的QQ';
    s.style.cssText = 'position:fixed;right:14px;top:48px;z-index:2147483647;padding:6px 12px;border-radius:16px;border:1px solid rgba(22,104,227,.35);background:rgba(255,255,255,.9);color:#1668e3;font-size:12px;cursor:pointer;box-shadow:0 2px 10px rgba(22,104,227,.12)';
    s.onclick = function () {
      fetch('/api/raw_config').then(function (r) { return r.json(); }).then(function (d) {
        var base = (d.napcat_base || '').replace(/\/$/, '');
        if (!base || base.indexOf('你的服务器') >= 0) { alert('请先到「连接设置」填写你自己的 NapCat 地址'); return; }
        try { window.chrome.webview.postMessage('open:' + base + '/webui'); } catch (e) { window.open(base + '/webui'); }
      });
    };
    document.body.appendChild(s);
  }

  function boot() { installShim(); addExit(); addScan(); }
  if (document.body) boot(); else document.addEventListener('DOMContentLoaded', boot);
})();
