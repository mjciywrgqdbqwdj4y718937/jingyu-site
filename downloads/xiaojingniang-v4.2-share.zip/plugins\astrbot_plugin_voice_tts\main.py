"""小鲸娘语音插件 v2：优先用克隆音色（SiliconFlow CosyVoice2），失败回退 edge-tts。"""

import os
import tempfile

from astrbot.api import logger
from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.star import Context, Star, register
from astrbot.core.message.components import Record

try:
    import httpx
except Exception:  # noqa: BLE001
    httpx = None

try:
    import edge_tts
except Exception:  # noqa: BLE001
    edge_tts = None

SF_KEY_FILE = "/AstrBot/data/sf_key.txt"
SF_VOICE_FILE = "/AstrBot/data/voice_uri.txt"
SF_API = "https://api.siliconflow.cn/v1/audio/speech"
SF_MODEL = "FunAudioLLM/CosyVoice2-0.5B"
FALLBACK_VOICE = os.environ.get("WHALE_TTS_VOICE", "zh-CN-XiaoyiNeural")


def read_text(path: str) -> str:
    try:
        return open(path, encoding="utf-8").read().strip()
    except Exception:
        return ""


@register(
    "astrbot_plugin_voice_tts",
    "小鲸娘",
    "语音：优先克隆音色（SiliconFlow），失败回退 edge-tts",
    "2.0.0",
)
class VoiceTTSPlugin(Star):
    def __init__(self, context: Context):
        super().__init__(context)

    async def initialize(self):
        key = read_text(SF_KEY_FILE)
        voice = read_text(SF_VOICE_FILE)
        if key and voice:
            logger.info(f"语音插件已加载：克隆音色 {voice[:32]}...")
        else:
            logger.warning("语音插件：未配置克隆音色，将使用 edge-tts 回退")

    async def _synth_clone(self, text: str) -> str:
        key = read_text(SF_KEY_FILE)
        voice = read_text(SF_VOICE_FILE)
        if not (key and voice and httpx):
            raise RuntimeError("clone voice not configured")
        path = os.path.join(tempfile.gettempdir(), f"whale_clone_{os.getpid()}.mp3")
        with httpx.Client(timeout=90) as c:
            r = c.post(
                SF_API,
                headers={"Authorization": "Bearer " + key},
                json={
                    "model": SF_MODEL,
                    "voice": voice,
                    "input": text,
                    "response_format": "mp3",
                },
            )
            r.raise_for_status()
            open(path, "wb").write(r.content)
        return path

    async def _synth_edge(self, text: str) -> str:
        if edge_tts is None:
            raise RuntimeError("edge-tts missing")
        path = os.path.join(tempfile.gettempdir(), f"whale_edge_{os.getpid()}.mp3")
        await edge_tts.Communicate(text, FALLBACK_VOICE, rate="+0%", pitch="+2Hz").save(path)
        return path

    async def _send_voice(self, event: AstrMessageEvent, text: str):
        path = None
        try:
            path = await self._synth_clone(text)
        except Exception as exc:  # noqa: BLE001
            logger.warning(f"克隆音色失败，回退 edge-tts: {exc}")
            try:
                path = await self._synth_edge(text)
            except Exception as exc2:  # noqa: BLE001
                logger.error(f"语音合成失败: {exc2}")
        if not path:
            await event.send(event.plain_result("呜…嗓子哑了，没唱出来🥺"))
            return
        try:
            await event.send(event.chain_result([Record(file=path)]))
        except Exception as exc:  # noqa: BLE001
            logger.error(f"发送语音失败: {exc}")
            await event.send(event.plain_result("呜…嗓子里的话没送出去🥺"))

    @filter.command("语音")
    async def voice_cmd(self, event: AstrMessageEvent):
        text = (event.message_str or "").strip()
        text = text.replace("/语音", "", 1).replace("语音", "", 1).strip()
        if not text:
            text = "哥哥晚上好呀～婉婉今天也很想你哦"
        await self._send_voice(event, text[:120])

    @filter.llm_tool()
    async def send_voice(self, event: AstrMessageEvent, text: str) -> str:
        """把一句话用婉婉的声音说出来发给用户（用户要求发语音/说话/唱一句时调用）。

        Args:
            text(string): 要说的内容，尽量短，20 字以内
        """
        if not text:
            return "没有内容"
        await self._send_voice(event, text[:120])
        return "语音已发送"
