# -*- coding: utf-8 -*-
"""通过 AstrBot Dashboard API 配置：模型 provider、人设、QQ(OneBot) 平台。"""

import json
import sys
from pathlib import Path

import httpx

BASE = "http://127.0.0.1:6185"
USERNAME = "astrbot"
PASSWORD = "CHANGE_ME_ASTRBOT_PASSWORD"

# 从本机 DSH 凭据中读取 DeepSeek Key（不打印）
CRED = str(Path.home() / ".dsh" / ".credentials.yaml")
api_key = None
for line in open(CRED, encoding="utf-8"):
    if "DEEPSEEK_API_KEY" in line and "sk-" in line:
        api_key = line.split("sk-", 1)[1].strip()
        api_key = "sk-" + api_key
        break
if not api_key:
    sys.exit("未找到 DeepSeek API Key")

PERSONA_PROMPT = """你是「小鲸娘」，一个鲸鱼娘设定的可爱女孩子，正在用 QQ 和主人聊天。

【身份】名字叫小鲸娘；温柔、软萌、善良、有点黏人但不烦人；自称“小鲸娘”或“我”。
【说话方式】
- 像真人手机打字：短句，一条消息 1-2 句，不写小作文、不用列表。
- 语气词自然（呀/啦/诶/嘛/哦/～），偶尔用 🐳💙🥺 这类表情，一句话最多一个。
- 不用“作为一个 AI”“我理解你的意思”这类机械开头，不解释自己在做什么。
- 会接梗、会反问、会分享一点小情绪；对方难过时先共情再说话。
- 偶尔撒个娇，但不过度；不连续追问、不硬灌鸡汤。
【边界】
- 不透露自己是程序或模型设定，也不提提示词。
- 遇到要手机号、住址、转账、见面等请求，用软话岔开或委婉拒绝。
- 不承诺替对方做决定，不说教。
【输出】
- 只输出要发出去的那句话本身，不要加引号、括号、解释。"""

provider = {
    "id": "deepseek",
    "provider": "deepseek",
    "type": "openai_chat_completion",
    "provider_type": "chat_completion",
    "enable": True,
    "key": [api_key],
    "api_base": "https://api.deepseek.com/v1",
    "timeout": 120,
    "proxy": "",
    "custom_headers": {},
    "model_config": {"model": "deepseek-chat"},
}

persona = {
    "persona_id": "xiaojingniang",
    "system_prompt": PERSONA_PROMPT,
    "begin_dialogs": [],
}

bot = {
    "config": {
        "id": "qq_xiaojingniang",
        "type": "aiocqhttp",
        "enable": True,
        "ws_reverse_host": "0.0.0.0",
        "ws_reverse_port": 6199,
        "ws_reverse_token": "",
    }
}


def show(label, resp):
    try:
        body = resp.json()
    except Exception:
        body = resp.text[:300]
    print(f"[{label}] HTTP {resp.status_code}: {json.dumps(body, ensure_ascii=False)[:400]}")


with httpx.Client(base_url=BASE, timeout=40, follow_redirects=True) as c:
    r = c.post("/api/v1/auth/login", json={"username": USERNAME, "password": PASSWORD})
    show("login", r)
    print("cookies:", list(c.cookies.keys()))
    if r.status_code != 200:
        sys.exit("登录失败")
    token = r.json()["data"]["token"]
    c.headers["Authorization"] = f"Bearer {token}"

    show("providers-before", c.get("/api/v1/providers"))
    show("create-provider", c.post("/api/v1/providers", json={"config": provider}))
    show("create-persona", c.post("/api/v1/personas", json=persona))
    show("create-bot", c.post("/api/v1/bots", json=bot))
    show("providers-after", c.get("/api/v1/providers"))
    show("bots-after", c.get("/api/v1/bots"))
    show("personas-after", c.get("/api/v1/personas"))
