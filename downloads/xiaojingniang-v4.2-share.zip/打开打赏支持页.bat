@echo off
chcp 65001 >nul
start "" "%~dp0打赏支持.html"
