#!/usr/bin/env python3
"""小鲸娘·云端守护：自动保活 / 掉线自愈 / 短信验证告警。

每 120 秒检查一次 NapCat 登录状态：
- 在线：记录 OK；
- 掉线且可自动登录：重启 NapCat（限频，避免风控）；
- 掉线且需要短信验证：写告警文件 + 可选 Server酱推送，不再盲目重试。
"""

import hashlib
import json
import os
import subprocess
import time
import urllib.request

NAP_CFG = "/opt/whale/napcat/webui.json"
STATUS = "/opt/whale/guard_status.json"
ALERT = "/opt/whale/ALERT_SMS_NEEDED.txt"
SC_KEY = os.environ.get("SERVERCHAN_KEY", "").strip()
MAX_RESTART_PER_HOUR = 2


def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def webui_login():
    cfg = json.load(open(NAP_CFG))
    token = cfg.get("token", "")
    h = hashlib.sha256((token + ".napcat").encode()).hexdigest()
    req = urllib.request.Request(
        "http://127.0.0.1:6099/api/auth/login",
        data=json.dumps({"hash": h}).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())["data"]["Credential"]


def nap_status(cred):
    req = urllib.request.Request(
        "http://127.0.0.1:6099/api/QQLogin/CheckLoginStatus",
        data=b"{}",
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + cred},
    )
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())["data"]


def notify(title: str, body: str) -> None:
    if not SC_KEY:
        return
    try:
        url = f"https://sctapi.ftqq.com/{SC_KEY}.send"
        data = urllib.parse.urlencode({"title": title, "desp": body}).encode()
        urllib.request.urlopen(url, data=data, timeout=10).read()
        log("已推送告警")
    except Exception as e:
        log(f"告警推送失败: {e}")


def write_status(**kw) -> None:
    kw["ts"] = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        json.dump(kw, open(STATUS, "w"), ensure_ascii=False, indent=2)
    except Exception:
        pass


def restart_napcat() -> None:
    subprocess.run(["docker", "restart", "napcat"], capture_output=True, timeout=120)
    log("已重启 NapCat")


def main() -> None:
    hist = []
    while True:
        try:
            cred = webui_login()
            st = nap_status(cred)
            if st.get("isLogin"):
                write_status(state="online", phase=st.get("loginPhase"))
                if os.path.exists(ALERT):
                    os.remove(ALERT)
                log("在线 OK")
            else:
                err = st.get("loginError") or ""
                need_sms = "验证码" in err or "短信" in err
                if need_sms:
                    if not os.path.exists(ALERT):
                        with open(ALERT, "w", encoding="utf-8") as f:
                            f.write(err + "\n需要主人配合短信验证 / 或搬回电脑\n")
                        log("需要短信验证，写告警，暂停自动重启")
                        notify("小鲸娘掉线：需要短信验证", err)
                    write_status(state="need_sms", error=err)
                else:
                    now = time.time()
                    hist = [t for t in hist if now - t < 3600]
                    if len(hist) < MAX_RESTART_PER_HOUR:
                        hist.append(now)
                        restart_napcat()
                        time.sleep(45)
                    write_status(state="offline_restarting", error=err)
            # 顺带检查容器是否存活
            out = subprocess.run(
                ["docker", "ps", "--format", "{{.Names}}"], capture_output=True, text=True
            ).stdout
            if "napcat" not in out:
                log("napcat 容器不在，尝试启动")
                subprocess.run(["docker", "start", "napcat"], capture_output=True)
        except Exception as e:
            log(f"守护异常: {e}")
        time.sleep(120)


if __name__ == "__main__":
    main()
