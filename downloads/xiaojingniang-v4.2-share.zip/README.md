# 小鲸娘 QQ 接入套件（大众版 · 可直接分享）

把「小鲸娘」风格的 AI 人格机器人接入 QQ 的通用方案：AstrBot 插件 + NapCat 协议端 + 运维脚本 + 云端部署配置。

> ⚠️ 本套件为**通用模板**：不含任何个人身份、课表、聊天记录或二维码数据。
> ⚠️ 使用前请阅读 `templates/.env.example`，填入你自己的密码与 API Key。
> ⚠️ QQ 第三方协议（NapCat 等）违反《QQ 用户协议》，存在封号风险；请仅用于学习研究，使用小号。

## 一、架构

```
QQ（小号）
  │  NapCat（OneBot v11，反向 WebSocket）
  ▼
AstrBot 4.29.x（人格 / LLM / 插件）
  ├── astrbot_plugin_beijing_time   时间校准（可选课表注入）
  ├── astrbot_plugin_humanize       拟人化：随机延迟 / 防重复 / 深夜降频
  ├── astrbot_plugin_voice_tts      语音：edge-tts 兜底，可选 SiliconFlow 克隆音色
  ├── astrbot_plugin_draw_cmd       /画图（Pollinations 免费）
  └── astrbot_plugin_video_scroll   /刷视频（B 站热门）
  ▼
DeepSeek（对话）｜ Tavily（搜索，可选）｜ SiliconFlow（音色克隆，可选）
```

## 二、快速开始（Linux + Docker）

1. 复制 `templates/.env.example` 为 `.env`，填写 `ASTRBOT_PASSWORD`、`DEEPSEEK_API_KEY`；
2. 安装 Docker：`bash cloud/install_docker.sh`；
3. 把 `plugins/*` 放进 AstrBot 的插件目录（默认 `AstrBot/data/plugins/`）；
4. 按需修改 `cloud/docker-compose.yml` 的挂载路径，`docker compose up -d`；
5. 打开 `http://YOUR_SERVER_IP:6185`，在 AstrBot 后台：
   - 新建 DeepSeek 提供商（OpenAI 兼容，`https://api.deepseek.com/v1`）
   - 新建人格（参考 `templates/persona.example.md`）
   - 平台选 `aiocqhttp`，反向 WS 端口 `6199`
6. 启动 NapCat 容器（建议 `mlikiowa/napcat-docker:v4.15.0`），扫码登录小号；
7. NapCat 的 OneBot 网络配置里添加反向 WS 客户端：`ws://127.0.0.1:6199/ws`。

## 三、Windows 本地方案

- `scripts/start_qq_stack.ps1`：一键启动 AstrBot + 主动消息 + 提权 NapCat；
- `scripts/health_check.ps1`：定时守护（建议只守护进程，不要自动重启协议端以免触发风控）；
- `scripts/qq_send.py`：通过 AstrBot API 发送消息；
- `scripts/proactive_qq.py`：主动消息调度器（默认 8 分钟一条，01:00–07:00 免打扰，带随机延迟）。

## 四、插件列表

| 插件 | 功能 | 依赖 |
|---|---|---|
| `astrbot_plugin_beijing_time` | 注入校准时间，可选课表（环境变量 `CLASSES` 配置） | httpx |
| `astrbot_plugin_humanize` | 随机打字延迟、最近 10 句防重复、深夜降频 | 无 |
| `astrbot_plugin_voice_tts` | 语音消息；克隆音色需 SiliconFlow Key，未配置则 edge-tts | httpx、edge-tts |
| `astrbot_plugin_draw_cmd` | `/画图 描述` + LLM 工具 | Pollinations（免费） |
| `astrbot_plugin_video_scroll` | `/刷视频` + LLM 工具（B 站热门） | 无 |
| `napcat-plugin-whale-guard` | NapCat 侧：掉线记录、保活心跳、WebUI 状态 | 无 |

## 五、自定义

- **人格**：参考 `templates/persona.example.md`，在 AstrBot 后台创建人格；
- **课表**（可选）：设置环境变量 `CLASSES="08:00-09:30,10:00-11:30"`，不设置则只注入时间；
- **音色**（可选）：SiliconFlow「上传参考音频」创建音色后，把 `voice_uri` 写入 `AstrBot/data/voice_uri.txt`、Key 写入 `AstrBot/data/sf_key.txt`。

## 六、目录结构

```
plugins/           自研 AstrBot 插件
napcat_plugins/    NapCat 插件
scripts/           Python / PowerShell 运维脚本
cloud/             Docker 部署配置
templates/         人格模板、环境变量模板
docs/              兼容性报告
```

## 七、风险提示

1. QQ 第三方协议有封号/限制风险，建议只用小号；不要用于营销、骚扰或自动化操作；
2. **不要尝试绕过腾讯安全检测**（所谓「破甲/防踢」）：违反平台规则且可能违法；
3. 机房 IP 挂 QQ 易被风控，稳定方案：住宅网络电脑常开，或使用官方 QQ 机器人；
4. `.env` 与密钥请勿提交到 Git。

---

## V4.2 分享包说明

- 本包为通用模板，已脱敏：不含真实 QQ、密码、Token、服务器 IP、个人路径。
- 使用前请阅读 `打赏支持.html` 与 `VERSION.txt`。
- 支持作者：`打赏支持.html`（微信 / 支付宝），完全自愿，不影响功能。

> 作者燃尽了，愿意打赏的朋友给作者一些支持吧。
