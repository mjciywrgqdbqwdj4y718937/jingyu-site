# Xiaojingniang desktop-pet health check - runs every 10 minutes (ASCII only).
# NOTE: the QQ bot itself now runs on the cloud server; this script only keeps the
# local desktop pet alive and must NOT start AstrBot / NapCat locally (they would
# fight with the cloud instance for the same QQ account).

$ws = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$log = Join-Path $ws "health.log"

function Write-Log($msg) {
    Add-Content -LiteralPath $log -Value ("[" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + "] " + $msg) -Encoding UTF8
}

# desktop pet (whale girl) - restart if it exited, clear stale singleton lock
$petExe = "D:\whalepet\DS-WhaleGirl-Pet.exe"
if (Test-Path $petExe) {
    $pet = Get-Process DS-WhaleGirl-Pet -ErrorAction SilentlyContinue
    if (-not $pet) {
        Write-Log "DOWN pet, starting..."
        Remove-Item Env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue
        Remove-Item "$env:APPDATA\DS-WhaleGirl-Pet\Singleton*" -Force -ErrorAction SilentlyContinue
        Start-Process -FilePath $petExe -WorkingDirectory "D:\whalepet" -WindowStyle Hidden
        Start-Sleep -Seconds 8
        $pet2 = Get-Process DS-WhaleGirl-Pet -ErrorAction SilentlyContinue
        if ($pet2) { Write-Log "RECOVERED pet running" } else { Write-Log "FAIL pet still not running" }
    } else {
        Write-Log "OK pet running"
    }
}
