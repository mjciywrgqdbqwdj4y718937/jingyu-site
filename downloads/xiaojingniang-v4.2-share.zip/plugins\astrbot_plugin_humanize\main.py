"""小鲸娘·拟人化插件：让云端 QQ 的行为更像真人，降低协议特征暴露。

做三件事：
1. 回复前随机延迟 0.6-2.2 秒（像真人在打字，避免秒回机器人特征）；
2. 同一轮对话里避免重复上一句一模一样的回复；
3. 深夜（01:00-07:00）不主动多话，回复也更短。
"""

import asyncio
import random
import time

from astrbot.api import logger
from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.star import Context, Star, register


@register(
    "astrbot_plugin_humanize",
    "小鲸娘",
    "拟人化：随机打字延迟、防重复回复、深夜降频",
    "1.0.0",
)
class HumanizePlugin(Star):
    def __init__(self, context: Context):
        super().__init__(context)
        self._last_reply = {}

    async def initialize(self):
        logger.info("拟人化插件已加载（随机延迟/防重复/深夜安静）")

    @filter.on_llm_request()
    async def delay_before_llm(self, event: AstrMessageEvent, req=None):
        """模型调用前随机等待，模拟真人输入节奏。"""
        hour = time.localtime().tm_hour
        # 深夜延迟更长一点，像困了；白天 0.6-2.2s
        if 1 <= hour < 7:
            delay = random.uniform(1.0, 3.0)
        else:
            delay = random.uniform(0.6, 2.2)
        await asyncio.sleep(delay)

    @filter.on_decorating_result()
    async def polish_result(self, event: AstrMessageEvent):
        """去掉与上一条完全相同的回复（防机器人式重复）。"""
        try:
            result = event.get_result()
            if result is None or not result.chain:
                return
            text = "".join(
                getattr(c, "text", "") for c in result.chain if getattr(c, "text", None)
            ).strip()
            if not text:
                return
            key = getattr(event, "unified_msg_origin", "") or "default"
            recent = self._last_reply.get(key, [])
            if not isinstance(recent, list):
                recent = [recent] if recent else []
            if text in recent[-5:]:
                # 与最近 5 句里任一句重复：换一个说法/加尾巴，避免一天内反复同样的话
                tails = ["～", "呀", "嗯", "💙", "🐳", "啦"]
                for comp in result.chain:
                    if getattr(comp, "text", None):
                        comp.text = comp.text.rstrip("。！？!?～ ") + random.choice(tails)
                        break
            recent.append(text)
            self._last_reply[key] = recent[-10:]
        except Exception as exc:  # noqa: BLE001
            logger.debug(f"humanize polish error: {exc}")
