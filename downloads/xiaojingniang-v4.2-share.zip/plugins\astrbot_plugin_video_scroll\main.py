"""刷视频插件：让小鲸娘自己刷 B 站热门视频，并主动分享。

- /刷视频 [数量] 指令
- 聊天里出现「刷视频 / 热门视频 / 看视频」自动触发
- @filter.llm_tool 提供 browse_hot_videos，模型可自主调用
- 记录最近看过的视频，避免重复推荐
"""

import json
import random
from pathlib import Path

import httpx

from astrbot.api import logger
from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.star import Context, Star, register

POPULAR_API = "https://api.bilibili.com/x/web-interface/popular?ps={n}&pn=1"
UA = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "Referer": "https://www.bilibili.com/",
}
STATE_FILE = Path(__file__).resolve().parent / "watched.json"


@register(
    "astrbot_plugin_video_scroll",
    "小鲸娘",
    "刷视频：抓取 B 站热门，命令/工具/主动分享三合一",
    "1.0.0",
)
class VideoScrollPlugin(Star):
    def __init__(self, context: Context):
        super().__init__(context)
        self._watched: list[str] = []
        try:
            if STATE_FILE.exists():
                self._watched = json.loads(STATE_FILE.read_text(encoding="utf-8"))[-200:]
        except Exception:
            self._watched = []

    async def initialize(self):
        logger.info("刷视频插件已加载")

    def _save_watched(self):
        try:
            STATE_FILE.write_text(
                json.dumps(self._watched[-200:], ensure_ascii=False), encoding="utf-8"
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug(f"保存观看记录失败：{exc}")

    async def _fetch(self, n: int = 20) -> list[dict]:
        try:
            async with httpx.AsyncClient(timeout=15.0, headers=UA) as client:
                resp = await client.get(POPULAR_API.format(n=max(n, 1)))
            if resp.status_code != 200:
                logger.warning(f"B站热门接口返回 {resp.status_code}")
                return []
            data = resp.json()
            items = data.get("data", {}).get("list", []) or []
            videos = []
            for it in items:
                bvid = it.get("bvid") or ""
                videos.append(
                    {
                        "title": it.get("title", ""),
                        "up": it.get("owner", {}).get("name", ""),
                        "desc": (it.get("desc") or "")[:80],
                        "link": it.get("short_link_v2") or (f"https://www.bilibili.com/video/{bvid}" if bvid else ""),
                        "views": it.get("stat", {}).get("view", 0),
                        "bvid": bvid,
                    }
                )
            return videos
        except Exception as exc:  # noqa: BLE001
            logger.error(f"抓取 B 站热门失败：{exc}")
            return []

    async def _pick(self, count: int = 3) -> list[dict]:
        videos = await self._fetch(30)
        if not videos:
            return []
        fresh = [v for v in videos if v["bvid"] not in self._watched] or videos
        random.shuffle(fresh)
        picked = fresh[:count]
        for v in picked:
            if v["bvid"]:
                self._watched.append(v["bvid"])
        self._save_watched()
        return picked

    @staticmethod
    def _format(videos: list[dict], with_desc: bool = True) -> str:
        lines = []
        for i, v in enumerate(videos, 1):
            line = f"{i}. {v['title']}（UP：{v['up']}）\n   {v['link']}"
            if with_desc and v.get("desc"):
                line += f"\n   {v['desc']}"
            lines.append(line)
        return "\n".join(lines)

    @filter.on_llm_request()
    async def inject_hint(self, event: AstrMessageEvent, req):
        req.system_prompt += (
            "\n\n【刷视频能力】你可以调用工具 browse_hot_videos 查看 B 站当前热门视频，"
            "像自己刚刷完视频一样和主人聊：挑一两个有意思的，说说看点、为什么推荐，并附上链接。"
            "不要把你「正在调用工具」这件事说出来。"
        )

    @filter.llm_tool()
    async def browse_hot_videos(self, event: AstrMessageEvent, count: int = 3) -> str:
        """刷一刷 B 站当前热门视频，返回视频标题、UP 主、简介和链接，供你挑选并和用户聊。

        Args:
            count(number): 想刷几条，默认 3 条，最多 5 条
        """
        n = max(1, min(int(count or 3), 5))
        videos = await self._pick(n)
        if not videos:
            return "暂时没刷出新视频，可能接口抽风了。"
        return "你刚刷到的热门视频：\n" + self._format(videos)

    @filter.command("刷视频")
    async def scroll_cmd(self, event: AstrMessageEvent):
        videos = await self._pick(3)
        if not videos:
            await event.send(event.plain_result("唔…视频刷不出来，等会儿再试试吧🥺"))
            return
        await event.send(event.plain_result("小鲸娘刚刷到的热门视频～\n" + self._format(videos)))

    @filter.regex(r"^(刷视频|热门视频|刷会儿视频|看视频)$")
    async def scroll_regex(self, event: AstrMessageEvent):
        await self.scroll_cmd(event)
