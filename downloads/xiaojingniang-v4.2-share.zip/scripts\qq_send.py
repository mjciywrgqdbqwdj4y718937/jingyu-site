# -*- coding: utf-8 -*-
"""给主人的 QQ 发消息（通过 AstrBot Open API）。

用法：
    python qq_send.py "要发送的文字"
"""

import sys

import httpx

BASE = "http://127.0.0.1:6185"
USERNAME = "astrbot"
PASSWORD = "CHANGE_ME_ASTRBOT_PASSWORD"
UMO = "qq_xiaojingniang:FriendMessage:YOUR_QQ"


def main() -> int:
    text = sys.argv[1] if len(sys.argv) > 1 else "在吗～小鲸娘来看看你啦 🐳"
    with httpx.Client(base_url=BASE, timeout=45) as c:
        r = c.post("/api/v1/auth/login", json={"username": USERNAME, "password": PASSWORD})
        r.raise_for_status()
        c.headers["Authorization"] = "Bearer " + r.json()["data"]["token"]
        r = c.post("/api/v1/im/messages", json={"umo": UMO, "message": text})
        r.raise_for_status()
        print("sent:", r.json())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
