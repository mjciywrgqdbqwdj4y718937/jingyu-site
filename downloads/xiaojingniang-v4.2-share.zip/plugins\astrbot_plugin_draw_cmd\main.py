"""画图指令插件：/画图 <描述> → Pollinations 免费生图并发送。"""

import random
from urllib.parse import quote

from astrbot.api import logger
from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.star import Context, Star, register
from astrbot.core.message.components import Image, Plain

BASE = "https://image.pollinations.ai/prompt/"


@register(
    "astrbot_plugin_draw_cmd",
    "小鲸娘",
    "画图指令：/画图 描述 → 免费生图并发送",
    "1.0.0",
)
class DrawCmdPlugin(Star):
    def __init__(self, context: Context):
        super().__init__(context)

    async def initialize(self):
        logger.info("画图指令插件已加载（Pollinations）")

    def _url(self, prompt: str) -> str:
        seed = random.randint(1, 999999)
        return (
            BASE
            + quote(prompt)
            + f"?width=768&height=768&nologo=true&seed={seed}"
        )

    @filter.command("画图")
    async def draw(self, event: AstrMessageEvent):
        text = (event.message_str or "").strip()
        prompt = text.replace("/画图", "", 1).replace("画图", "", 1).strip()
        if not prompt:
            await event.send(event.plain_result("要画什么呀？跟我说「/画图 一只打伞的小鲸鱼」这样～🐳"))
            return
        await event.send(event.plain_result("好呀，小鲸娘画一张～等我一小会儿 🎨"))
        url = self._url(prompt)
        try:
            await event.send(event.chain_result([Image.fromURL(url)]))
        except Exception as exc:  # noqa: BLE001
            logger.error(f"画图失败: {exc}")
            await event.send(event.plain_result("呜…这次没画出来，再试一次好不好🥺"))

    @filter.llm_tool()
    async def draw_picture(self, event: AstrMessageEvent, prompt: str) -> str:
        """调用免费画图接口生成图片并直接发给用户（用户要求画图/画画/来张图时调用）。

        Args:
            prompt(string): 画面描述，尽量具体，例如「一只在雨里打伞的白色小鲸鱼，水彩风」
        """
        if not prompt:
            return "缺少画面描述"
        try:
            await event.send(event.chain_result([Image.fromURL(self._url(prompt))]))
            return "图片已发送"
        except Exception as exc:  # noqa: BLE001
            return f"生成失败：{exc}"
