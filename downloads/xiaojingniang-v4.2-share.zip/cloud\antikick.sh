#!/bin/bash
# 小鲸娘·反踢脚本（版本固定/降级）
# 依据：NapCat 官方 issue #1728 —— 最新版 QQ/NapCat 会被风控频繁踢下线，
#      临时方案是降级到 NapCat 4.15.0 + 对应旧版 QQ。
# 用法：bash antikick.sh [v4.15.0]
set -e
cd /opt/whale
TAG="${1:-v4.15.0}"

echo "== 1. 备份当前 compose =="
cp docker-compose.yml "docker-compose.yml.bak-$(date +%H%M%S)"

echo "== 2. 固定 NapCat 镜像版本: $TAG =="
python3 - "$TAG" <<'PY'
import sys, yaml
tag = sys.argv[1]
p = "/opt/whale/docker-compose.yml"
cfg = yaml.safe_load(open(p))
cfg["services"]["napcat"]["image"] = f"mlikiowa/napcat-docker:{tag}"
yaml.safe_dump(cfg, open(p, "w"), allow_unicode=True, sort_keys=False)
print("image ->", cfg["services"]["napcat"]["image"])
PY

echo "== 3. 拉取镜像（已拉过则秒过）=="
docker pull "mlikiowa/napcat-docker:$TAG" || true

echo "== 4. 重建容器（保留数据卷）=="
docker compose up -d napcat
sleep 30

echo "== 5. 版本确认 =="
docker logs napcat 2>&1 | grep -iE "NapCat.Core Version|QQ Version|版本" | head -3
docker exec napcat sh -c "cat /opt/QQ/resources/app/package.json 2>/dev/null | grep -m1 version" || true
docker ps --format '{{.Names}} {{.Status}}'
echo "完成：容器已用 $TAG，请扫码登录并观察 20-30 分钟。"
