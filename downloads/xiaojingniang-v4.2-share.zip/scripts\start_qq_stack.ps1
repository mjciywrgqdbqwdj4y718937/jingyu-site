# Restart the QQ bot stack after a reboot or DSH restart (ASCII only).
# Usage: double-click, or run in PowerShell.

$ws = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location $ws

Write-Output "1) Starting AstrBot ..."
$astr = Join-Path $ws ".venv-astrbot\Scripts\astrbot.exe"
$astrHome = Join-Path $ws "astrbot_home"
Start-Process -FilePath $astr -ArgumentList "run" -WorkingDirectory $astrHome -WindowStyle Hidden -RedirectStandardOutput (Join-Path $astrHome "astrbot_stdout.log") -RedirectStandardError (Join-Path $astrHome "astrbot_stderr.log")
Start-Sleep -Seconds 30

Write-Output "2) Sending boot greeting for current Beijing time ..."
$py = Join-Path $ws ".venv-astrbot\Scripts\python.exe"
$greet = Join-Path $ws "boot_greeting.py"
Start-Process -FilePath $py -ArgumentList $greet -WorkingDirectory $ws -WindowStyle Hidden

Write-Output "3) Starting proactive scheduler ..."
$script = Join-Path $ws "proactive_qq.py"
Remove-Item (Join-Path $ws "qq_persona\STOP") -Force -ErrorAction SilentlyContinue
Start-Process -FilePath $py -ArgumentList @($script, "480") -WorkingDirectory $ws -WindowStyle Hidden

Write-Output "4) Starting NapCat (UAC prompt: click Yes) ..."
Start-Process -FilePath "cmd.exe" -ArgumentList '/c', ('"' + $ws + '\napcat\launcher.bat"') -Verb RunAs -WindowStyle Normal

Start-Sleep -Seconds 15
Write-Output "Done. Check QQ / AstrBot WebUI http://localhost:6185"
