"""北京时间校准插件（通用版）：注入校准后的北京时间，可选注入课表状态。

课表可通过环境变量 CLASSES 配置，例如：
    CLASSES="08:00-09:30,10:00-11:30"
不配置则只提供时间，不做课节判断。
"""

import os
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import httpx

from astrbot.api import logger
from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.star import Context, Star, register

TZ = ZoneInfo("Asia/Shanghai")
WEEK = "一二三四五六日"


def load_classes():
    raw = os.environ.get("CLASSES", "").strip()
    if not raw:
        return []
    out = []
    for part in raw.split(","):
        part = part.strip()
        if "-" in part:
            s, e = part.split("-", 1)
            out.append((s.strip(), e.strip()))
    return out


CLASSES = load_classes()

TIME_SOURCES = [
    ("https://api.m.taobao.com/rest/api3.do?api=mtop.common.getTimestamp", "taobao"),
    ("https://quan.suning.com/getSysTime.do", "suning"),
]


def _hm(s: str):
    h, m = s.split(":")
    return int(h), int(m)


@register(
    "astrbot_plugin_beijing_time",
    "community",
    "北京时间校准 + 可选课表：注入校准时间与当前课节",
    "2.0.0",
)
class BeijingTimePlugin(Star):
    def __init__(self, context: Context):
        super().__init__(context)
        self._offset = timedelta(0)
        self._source = "system"

    async def initialize(self):
        await self._calibrate()
        logger.info(
            f"北京时间插件已加载，校准偏移 {self._offset.total_seconds():+.3f}s（来源：{self._source}）"
        )

    async def _calibrate(self):
        for url, kind in TIME_SOURCES:
            try:
                async with httpx.AsyncClient(timeout=6.0) as client:
                    resp = await client.get(url)
                if resp.status_code != 200:
                    continue
                data = resp.json()
                raw = None
                if kind == "taobao":
                    raw = data.get("data", {}).get("t")
                elif kind == "suning":
                    raw = data.get("sysTime2") or data.get("sysTime1")
                if not raw:
                    continue
                digits = str(raw)
                ms = int(digits[:13]) if len(digits) >= 13 else int(digits) * 1000
                server = datetime.fromtimestamp(ms / 1000, tz=timezone.utc)
                local = datetime.now(timezone.utc)
                delta = (server - local).total_seconds()
                if abs(delta) <= 30:
                    self._offset = timedelta(seconds=delta)
                    self._source = kind
                return
            except Exception as exc:  # noqa: BLE001
                logger.debug(f"北京时间校准源 {kind} 失败：{exc}")

    def now(self) -> datetime:
        return datetime.now(timezone.utc).astimezone(TZ) + self._offset

    def _formatted(self) -> str:
        n = self.now()
        return f"{n.strftime('%Y-%m-%d %H:%M:%S')} 星期{WEEK[n.weekday()]}"

    def class_status(self) -> str:
        if not CLASSES:
            return "（未配置课表）"
        n = self.now()
        cur = n.hour * 60 + n.minute
        for idx, (start, end) in enumerate(CLASSES, 1):
            sh, sm = _hm(start)
            eh, em = _hm(end)
            s, e = sh * 60 + sm, eh * 60 + em
            if s <= cur < e:
                return f"第{idx}节课进行中（{start}-{end}，还有约 {e - cur} 分钟下课）"
            if cur < s and idx == 1:
                return f"还没开始上课（第1节 {start} 开始）"
        for idx in range(len(CLASSES) - 1):
            ep = _hm(CLASSES[idx][1])[0] * 60 + _hm(CLASSES[idx][1])[1]
            sn = _hm(CLASSES[idx + 1][0])[0] * 60 + _hm(CLASSES[idx + 1][0])[1]
            if ep <= cur < sn:
                return f"课间休息（第{idx+1}节已下课，第{idx+2}节 {CLASSES[idx+1][0]} 开始）"
        return "今天的课已经结束"

    def schedule_text(self) -> str:
        if not CLASSES:
            return "还没有配置课表哦（可设置环境变量 CLASSES）"
        lines = [f"今天（星期{WEEK[self.now().weekday()]}）的课表："]
        for i, (s, e) in enumerate(CLASSES, 1):
            lines.append(f"  第{i}节 {s}-{e}")
        lines.append(f"现在状态：{self.class_status()}")
        return "\n".join(lines)

    @filter.on_llm_request()
    async def inject_time(self, event: AstrMessageEvent, req):
        text = (
            f"\n\n【当前北京时间】{self._formatted()}（已校准，时区 Asia/Shanghai）"
            f"\n【当前课节状态】{self.class_status()}"
            "\n规则：需要判断时间/课节时以这里为准，不要自己编时间。"
        )
        req.system_prompt += text

    @filter.command("time")
    async def time_cmd(self, event: AstrMessageEvent):
        await event.send(
            event.plain_result(f"现在北京时间 {self._formatted()} 呀～\n{self.class_status()}")
        )

    @filter.command("课表")
    async def schedule_cmd(self, event: AstrMessageEvent):
        await event.send(event.plain_result(self.schedule_text()))
