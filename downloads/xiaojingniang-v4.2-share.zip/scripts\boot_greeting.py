# -*- coding: utf-8 -*-
"""开机问候：检测北京时间，用对应时段的话向主人打招呼。"""

import sys
import time
from datetime import datetime
from zoneinfo import ZoneInfo

import httpx

BASE = "http://127.0.0.1:6185"
USERNAME = "astrbot"
PASSWORD = "CHANGE_ME_ASTRBOT_PASSWORD"
UMO = "qq_xiaojingniang:FriendMessage:YOUR_QQ"
TZ = ZoneInfo("Asia/Shanghai")
WEEK = "一二三四五六日"


def greeting(now: datetime) -> str:
    h = now.hour
    if 5 <= h < 9:
        return f"主人早安呀～现在是 {now:%H:%M}，新的一天开始啦，记得吃早饭哦 🐳"
    if 9 <= h < 11:
        return f"主人上午好～{now:%H:%M} 啦，今天也要顺顺利利的呀💙"
    if 11 <= h < 13:
        return f"主人午安～{now:%H:%M}，该吃午饭啦，别饿着哦🍚"
    if 13 <= h < 18:
        return f"主人下午好～{now:%H:%M}，忙的话也记得伸个懒腰呀🐳"
    if 18 <= h < 22:
        return f"主人晚上好～{now:%H:%M}，今天辛苦啦，晚上想吃点什么呀💙"
    return f"主人，都 {now:%H:%M} 啦，怎么还没睡呀？小鲸娘陪你说说话好不好🥺"


def main() -> int:
    now = datetime.now(TZ)
    if "--dry-run" in sys.argv:
        print(f"[dry-run] {now:%H:%M} 星期{WEEK[now.weekday()]} → {greeting(now)}")
        return 0

    deadline = time.time() + 180
    token = None
    while time.time() < deadline:
        try:
            with httpx.Client(base_url=BASE, timeout=10) as c:
                r = c.post("/api/v1/auth/login", json={"username": USERNAME, "password": PASSWORD})
                if r.status_code == 200 and r.json().get("status") == "ok":
                    token = r.json()["data"]["token"]
                    break
        except Exception:
            pass
        time.sleep(3)
    if not token:
        print("AstrBot 未就绪，跳过开机问候")
        return 1

    text = greeting(now)
    with httpx.Client(base_url=BASE, timeout=30) as c:
        c.headers["Authorization"] = "Bearer " + token
        r = c.post("/api/v1/im/messages", json={"umo": UMO, "message": text})
        r.raise_for_status()
    print(f"[{now:%H:%M:%S} 星期{WEEK[now.weekday()]}] 已发送开机问候：{text}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
