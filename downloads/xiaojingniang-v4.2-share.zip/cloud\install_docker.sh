#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

echo "== 1. 清理卡住的 apt =="
pkill -9 -f "apt-get" 2>/dev/null || true
pkill -9 -f "get-docker.sh" 2>/dev/null || true
sleep 1

echo "== 2. 从阿里云镜像下载 docker 静态包 =="
VER=$(curl -fsSL https://mirrors.aliyun.com/docker-ce/linux/static/stable/x86_64/ | grep -o 'docker-[0-9][0-9.]*\.tgz' | sort -V | tail -1)
echo "版本: $VER"
curl -fsSL --retry 3 -o /tmp/docker.tgz "https://mirrors.aliyun.com/docker-ce/linux/static/stable/x86_64/$VER"
tar -xzf /tmp/docker.tgz -C /usr/local/bin --strip-components=1
chmod +x /usr/local/bin/docker* /usr/local/bin/containerd* /usr/local/bin/runc /usr/local/bin/ctr 2>/dev/null || true
docker --version

echo "== 3. 配置 daemon 与 systemd 服务 =="
mkdir -p /etc/docker
cat > /etc/docker/daemon.json <<'EOF'
{
  "registry-mirrors": ["https://docker.m.daocloud.io", "https://hub-mirror.c.163.com"],
  "data-root": "/var/lib/docker"
}
EOF
cat > /etc/systemd/system/docker.service <<'EOF'
[Unit]
Description=Docker Engine
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/local/bin/dockerd
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable docker >/dev/null 2>&1 || true
systemctl restart docker
sleep 4
docker info --format '{{.ServerVersion}} / {{.Driver}}' 2>&1 || (journalctl -u docker -n 20 --no-pager)

echo "== 4. 安装 docker compose 插件 =="
mkdir -p /usr/local/lib/docker/cli-plugins
curl -fsSL --retry 3 -o /usr/local/lib/docker/cli-plugins/docker-compose \
  "https://gh-proxy.com/https://github.com/docker/compose/releases/latest/download/docker-compose-linux-x86_64" || \
  curl -fsSL --retry 3 -o /usr/local/lib/docker/cli-plugins/docker-compose \
  "https://mirror.ghproxy.com/https://github.com/docker/compose/releases/latest/download/docker-compose-linux-x86_64"
chmod +x /usr/local/lib/docker/cli-plugins/docker-compose
docker compose version

echo "== 5. 完成 =="
uname -a
free -m | head -2
