// 小鲸娘 · 反踢观察插件（NapCat 插件）
// 功能：
// 1. 记录掉线/踢出相关事件（KickedOffLine / 离线）；
// 2. 每 60 秒调用一次 get_status 保活（轻量，不产生消息）；
// 3. 在 NapCat WebUI 暴露 /whale-guard/status 查询在线/掉线次数。
// 说明：插件无法改变 IP 和客户端平台特征，真正的反踢靠「版本降级 + 拟人化 + 守护服务」。

import fs from 'node:fs';
import path from 'node:path';

let timer = null;
let ctxRef = null;
let stats = { online: true, kicks: 0, lastEvent: '', lastCheck: '', checks: 0 };

export const plugin_init = async (ctx) => {
  ctxRef = ctx;
  ctx.logger.log('[whale-guard] 插件已加载，开始保活心跳');
  try {
    ctx.router.getNoAuth('/whale-guard/status', (req, res) => {
      res.json({ code: 0, data: stats });
    });
  } catch (e) {
    ctx.logger.warn('[whale-guard] 注册路由失败: ' + e);
  }
  timer = setInterval(async () => {
    try {
      const status = await ctx.actions.call(
        'get_status', void 0, ctx.adapterName, ctx.pluginManager.config,
      );
      stats.online = !!(status && status.online !== false);
      stats.checks += 1;
      stats.lastCheck = new Date().toISOString();
      stats.lastEvent = 'heartbeat';
    } catch (e) {
      stats.online = false;
      stats.lastEvent = 'heartbeat_failed: ' + String(e).slice(0, 120);
      ctx.logger.warn('[whale-guard] 保活心跳失败: ' + e);
    }
  }, 60000);
};

export const plugin_onevent = async (ctx, event) => {
  try {
    const raw = JSON.stringify(event || {});
    if (/KickedOffLine|下线|offline|失效/i.test(raw)) {
      stats.kicks += 1;
      stats.online = false;
      stats.lastEvent = raw.slice(0, 500);
      ctx.logger.warn('[whale-guard] 检测到掉线事件（累计 ' + stats.kicks + ' 次）');
      try {
        fs.writeFileSync(path.join(ctx.dataPath, 'kicks.log'), new Date().toISOString() + ' ' + raw.slice(0, 2000) + '\n', { flag: 'a' });
      } catch (e) {}
    }
  } catch (e) {}
};

export const plugin_cleanup = (ctx) => {
  if (timer) clearInterval(timer);
  ctx.logger.log('[whale-guard] 插件已卸载');
};
