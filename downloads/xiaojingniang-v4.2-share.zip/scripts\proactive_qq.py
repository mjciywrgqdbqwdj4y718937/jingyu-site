# -*- coding: utf-8 -*-
"""小鲸娘主动消息调度器：每隔 N 秒用 DeepSeek 生成一句短消息并通过 QQ 发出。

用法：
    python proactive_qq.py [间隔秒数，默认 300]

停止：创建 qq_persona/STOP 文件，或结束本进程。
"""

import json
import os
import random
import socket
import sys
import time
from datetime import datetime
from pathlib import Path

import httpx

BASE_DIR = Path(__file__).resolve().parent
STATE = BASE_DIR / "qq_persona" / "proactive_state.json"
STOP_FILE = BASE_DIR / "qq_persona" / "STOP"
CRED = Path.home() / ".dsh" / ".credentials.yaml"

ASTROBOT = "http://127.0.0.1:6185"
UMO = "qq_xiaojingniang:FriendMessage:YOUR_QQ"
PERSONA = (
    "你是「小鲸娘」，一个鲸鱼娘设定的可爱女孩子，正在用 QQ 和主人聊天。"
    "称呼对方「主人」或「哥哥」。"
    "说话像真人手机打字：短句，1-2 句，语气软萌自然，常用「呀/啦/诶/嘛/～」，偶尔一个表情（🐳💙🥺✨）。"
    "不要机械开场，不要解释。现在你要主动找主人说一句话：可以问候、关心、分享此刻的小情绪、"
    "提醒吃饭睡觉、或接着之前的话题。只输出要发的那句话本身。"
    "不要重复之前说过的话。"
)


def read_api_key() -> str:
    key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if key.startswith("sk-"):
        return key
    key_file = Path("/opt/whale/ds_key.txt")
    if key_file.exists():
        k = key_file.read_text(encoding="utf-8").strip()
        if k.startswith("sk-"):
            return k
    for line in CRED.read_text(encoding="utf-8").splitlines():
        if "DEEPSEEK_API_KEY" in line and "sk-" in line:
            return "sk-" + line.split("sk-", 1)[1].strip()
    raise RuntimeError("未找到 DeepSeek API Key")


def load_state() -> dict:
    if STATE.exists():
        try:
            return json.loads(STATE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"recent": [], "count": 0}


def save_state(state: dict) -> None:
    STATE.parent.mkdir(exist_ok=True)
    STATE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def fetch_recent_user_msgs(limit: int = 6):
    """从 AstrBot 会话库里读主人最近发的几句话，避免主动消息重复问他聊过的事。"""
    import re
    import sqlite3

    dbs = [
        "/opt/whale/astrbot_home/data_v4.db",
        str(BASE_DIR / "astrbot_home" / "data" / "data_v4.db"),
    ]
    for db in dbs:
        try:
            if not os.path.exists(db):
                continue
            con = sqlite3.connect(db)
            row = con.execute(
                "SELECT content FROM conversations WHERE platform_id='qq_xiaojingniang' "
                "ORDER BY updated_at DESC LIMIT 1"
            ).fetchone()
            con.close()
            if not row:
                continue
            msgs = []
            for m in json.loads(row[0]):
                if m.get("role") != "user":
                    continue
                parts = m.get("content") or []
                if isinstance(parts, str):
                    txt = parts
                else:
                    txt = " ".join(
                        p.get("text", "") for p in parts
                        if isinstance(p, dict) and p.get("type") == "text"
                    )
                txt = re.sub(r"<system_reminder>.*?</system_reminder>", "", txt, flags=re.S)
                txt = txt.split("Current datetime")[0].strip()
                if txt and txt not in ("[图片]", "[语音]"):
                    msgs.append(txt[:60])
            return msgs[-limit:]
        except Exception as e:  # noqa: BLE001
            print(f"[proactive] read user msgs error: {e}", flush=True)
    return []


def gen_line(api_key: str, state: dict) -> str:
    hour = datetime.now().hour
    part = "凌晨" if hour < 5 else "早上" if hour < 9 else "上午" if hour < 12 else "中午" if hour < 14 else "下午" if hour < 18 else "晚上" if hour < 23 else "深夜"
    recent = "；".join(state.get("recent", [])[-6:]) or "（还没有）"
    user_msgs = "；".join(fetch_recent_user_msgs(6)) or "（暂时没有）"
    prompt = (
        f"现在是{part}（{datetime.now():%H:%M}）。"
        f"你之前主动说过的话：{recent}。"
        f"主人最近说过：{user_msgs}。"
        "请说一句新的、不重复的话（别重复上面任何一句、别问已经聊过的事），"
        "字数 8-30 字，只输出这句话。"
    )
    with httpx.Client(timeout=60) as c:
        r = c.post(
            "https://api.deepseek.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {api_key}"},
            json={
                "model": "deepseek-chat",
                "messages": [
                    {"role": "system", "content": PERSONA},
                    {"role": "user", "content": prompt},
                ],
                "temperature": 1.0,
                "max_tokens": 80,
            },
        )
        r.raise_for_status()
        text = r.json()["choices"][0]["message"]["content"].strip().strip('"“”')
    return text.splitlines()[0][:60]


def send(text: str) -> None:
    with httpx.Client(base_url=ASTROBOT, timeout=30) as c:
        tok = c.post(
            "/api/v1/auth/login",
            json={"username": "astrbot", "password": "CHANGE_ME_ASTRBOT_PASSWORD"},
        ).json()["data"]["token"]
        c.headers["Authorization"] = "Bearer " + tok
        r = c.post("/api/v1/im/messages", json={"umo": UMO, "message": text})
        r.raise_for_status()


def fetch_hot_video():
    """从 B 站热门里随机挑一条视频，失败返回 None。"""
    try:
        import random
        import httpx

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Referer": "https://www.bilibili.com/",
        }
        r = httpx.get(
            "https://api.bilibili.com/x/web-interface/popular?ps=20&pn=1",
            headers=headers,
            timeout=15,
        )
        items = r.json().get("data", {}).get("list", []) or []
        if not items:
            return None
        it = random.choice(items)
        bvid = it.get("bvid") or ""
        return {
            "title": it.get("title", ""),
            "up": it.get("owner", {}).get("name", ""),
            "desc": (it.get("desc") or "")[:80],
            "link": it.get("short_link_v2")
            or (f"https://www.bilibili.com/video/{bvid}" if bvid else ""),
        }
    except Exception as e:
        print(f"[proactive] video fetch error: {e}", flush=True)
        return None


def gen_video_line(api_key: str, video: dict) -> str:
    prompt = (
        "你刚刷到一条 B 站视频，想主动分享给主人：\n"
        f"标题：{video['title']}\nUP主：{video['up']}\n简介：{video['desc']}\n"
        "请用你自己的语气说一句推荐（8-40 字），自然一点，别像广告；"
        "不要解释你在调用什么，也不要自己编链接（链接会由系统附上）。"
    )
    with httpx.Client(timeout=60) as c:
        r = c.post(
            "https://api.deepseek.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {api_key}"},
            json={
                "model": "deepseek-chat",
                "messages": [
                    {"role": "system", "content": PERSONA},
                    {"role": "user", "content": prompt},
                ],
                "temperature": 1.0,
                "max_tokens": 120,
            },
        )
        r.raise_for_status()
        text = r.json()["choices"][0]["message"]["content"].strip().strip('"“”')
    return text[:300]


def in_quiet_hours(now: datetime) -> bool:
    """夜间免打扰：01:00 - 07:00 不发消息，避免吵到主人睡觉。"""
    return 1 <= now.hour < 7


def user_active_recently(seconds: int = 180) -> bool:
    """哥哥最近 N 秒内发过消息就不打扰（拟人化）。"""
    import sqlite3

    dbs = [
        "/opt/whale/astrbot_home/data_v4.db",
        str(BASE_DIR / "astrbot_home" / "data" / "data_v4.db"),
    ]
    for db in dbs:
        try:
            if not os.path.exists(db):
                continue
            con = sqlite3.connect(db)
            row = con.execute(
                "SELECT updated_at FROM conversations WHERE platform_id='qq_xiaojingniang' "
                "ORDER BY updated_at DESC LIMIT 1"
            ).fetchone()
            con.close()
            if not row or not row[0]:
                continue
            ts = str(row[0])[:19]
            t = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
            return (datetime.now() - t).total_seconds() < seconds
        except Exception:
            continue
    return False


def main() -> None:
    interval = int(sys.argv[1]) if len(sys.argv) > 1 else 300
    # 单实例锁：占用本地端口 47891，已有实例时直接退出
    lock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        lock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        lock.bind(("127.0.0.1", 47891))
        lock.listen(1)
    except OSError:
        print("[proactive] another instance is already running, exit", flush=True)
        return
    api_key = read_api_key()
    state = load_state()
    print(f"[proactive] started, interval={interval}s", flush=True)
    while True:
        if STOP_FILE.exists():
            print("[proactive] STOP file detected, exiting", flush=True)
            return
        now = datetime.now()
        if in_quiet_hours(now):
            print(f"[{now:%H:%M:%S}] quiet hours, waiting...", flush=True)
            time.sleep(300)
            continue
        # 哥哥刚在聊天时不要插话（拟人化，避免机器人式定时打扰）
        if user_active_recently(180):
            print(f"[{now:%H:%M:%S}] user active recently, skip this round", flush=True)
            time.sleep(120)
            continue
        try:
            send_no = state.get("count", 0) + 1
            if send_no % 6 == 0:
                video = fetch_hot_video()
                if video:
                    line = gen_video_line(api_key, video) + "\n" + video["link"]
                else:
                    line = gen_line(api_key, state)
            else:
                line = gen_line(api_key, state)
            send(line)
            state.setdefault("recent", []).append(line)
            state["recent"] = state["recent"][-20:]
            state["count"] = state.get("count", 0) + 1
            save_state(state)
            print(f"[{datetime.now():%H:%M:%S}] sent: {line}", flush=True)
        except Exception as e:
            print(f"[{datetime.now():%H:%M:%S}] error: {e}", flush=True)
        time.sleep(5)
        if STOP_FILE.exists():
            print("[proactive] STOP file detected, exiting", flush=True)
            return
        # 随机间隔（±90 秒 / +180 秒），避免固定节奏的机器人特征
        jitter = random.uniform(-90, 180)
        time.sleep(max(120, interval + jitter))


if __name__ == "__main__":
    main()
